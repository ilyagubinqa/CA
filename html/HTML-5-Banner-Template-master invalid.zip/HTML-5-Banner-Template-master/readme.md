# Before you start, you will need:

- Node.js
- Grunt
- imageOptim https://imageoptim.com/mac
- imageAlpha https://pngmini.com/

# Steps

- Navigate into this folder (in the Terminal) and run 'npm install'
- Run 'grunt'
- This will start watching your CSS and JS for changes, then will recompile when it sees some
- Run 'grunt dist' to build for production
